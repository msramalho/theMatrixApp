package maps.bank_matrix;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText password;
    private TextView loginTip;
    private ImageView fingerprintIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        password = findViewById(R.id.password);
        loginTip = findViewById(R.id.textTipLogin);
        fingerprintIcon = findViewById(R.id.fingerprintIcon);

        // display fingerprint option if device has fingerprint
        /*BiometricManager biometricManager = BiometricManager.from(this);
        switch (biometricManager.canAuthenticate()) {
            case BiometricManager.BIOMETRIC_SUCCESS:
                Log.d("MY_APP_TAG", "App can authenticate using biometrics.");
                break;
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                Log.e("MY_APP_TAG", "No biometric features available on this device.");
                break;
            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                Log.e("MY_APP_TAG", "Biometric features are currently unavailable.");
                break;
            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                Log.e("MY_APP_TAG", "The user hasn't associated " +
                        "any biometric credentials with their account.");
                break;
        }*/

        //code to make keyboard enter be the same as button click
        password.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN){
                if(keyCode == KeyEvent.KEYCODE_ENTER){
                    advanceToMatrix(findViewById(R.id.go_btn));
                    return true;
                }
            }
            return false;
        });


    }

    public void advanceToMatrix(View view) {
        validatePassword(password.getText().toString());
    }

    public void resetPassword(View view) {
        promptNewPassword();
    }

    private void validatePassword(String attempt){
        Preferences p = new Preferences(this);

        if (!p.isPasswordDefined()){
            Toast.makeText(MainActivity.this, "No password defined...", Toast.LENGTH_SHORT).show();
            promptNewPassword();
            return;
        }

        if(p.validatePassword(attempt)){//correct password
            password.setText("");
            Intent intentMatrix =  new Intent(this, MatrixList.class);
            intentMatrix.putExtra("passkey", attempt);
            startActivity(intentMatrix);
        }else{
            Toast.makeText(MainActivity.this, "Wrong password", Toast.LENGTH_SHORT).show();
        }
    }

    private void changePassword(String oldP, String newP){
        Preferences p = new Preferences(this);
        if(p.changePassword(oldP, newP)){
            Toast.makeText(MainActivity.this, "Password set", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(MainActivity.this, "Wrong password", Toast.LENGTH_SHORT).show();
        }
    }

    private void promptNewPassword(){
        LayoutInflater inflater = this.getLayoutInflater();

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
            .setMessage("Enter the old and the new password")
            .setTitle("Change Password")
            .setNegativeButton("Abort", null)
            .setPositiveButton("Go", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Dialog dialogObj = (Dialog) dialog;
                    EditText oldEt = dialogObj.findViewById(R.id.oldP);
                    EditText newEt = dialogObj.findViewById(R.id.newP);

                    changePassword(oldEt.getText().toString(), newEt.getText().toString());
                }
            })
            .setView(inflater.inflate(R.layout.change_password, null));
        AlertDialog dialog = builder.create();
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        dialog.show();
    }

}
